import random

print('Welcome to Hangman by Simon')
print('After 5 wrong guesses, you lose!')

words = ['apple', 'man', 'random', 'hacker', 'fun', 'hotdog', 'food', 'burger', 'family', 'class', 'pen', 'book']

secret_word = random.choice(words)
display_word = []

for letter in secret_word:
    display_word += "_"
print(display_word)

numwrongguess = 0
game_over = False
game_lost = False

while not game_over:
    guess = input("Guess a letter: ").lower()
    for position in range(len(secret_word)):
        letter = secret_word[position]
        if letter == guess:
            display_word[position] = letter


    print(display_word)

    if "_" not in display_word:
        print('You win!')
        game_over = True

    if guess not in secret_word:
        numwrongguess += 1

    if numwrongguess >= 5:
        game_lost = True
        game_over = True

    if game_lost == True:
        print('You lost!')